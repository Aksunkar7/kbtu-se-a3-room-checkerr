# Screenshots — Assignment #03

Smart Campus Room Availability Checker, Bolt.new prototype.
Base data in every shot: Room 301, `now = 540`, `existing = [(600, 660)]`.

| File | What it shows |
|---|---|
| `01_preview_v1_first_generation.png` | The first usable generation. One room, the fictional booking shown read-only, two integer-minute fields. No login, backend or booking creation anywhere, so the prohibitions in the prompt were respected. |
| `02_ac1_non_integer_minutes.png` | `700.5 / 760.5` → Unavailable, `"AC1: start and end must be integer minutes. Received start=700.5, end=760.5."` This is the input on which `booking_v1.py` returned `True`; the prototype rejects it. |
| `03_ac1_empty_fields.png` | Both fields empty → Unavailable with guidance rather than a crash or a blank screen. |
| `04_ac1_negative_start.png` | `−10 / 50` → Unavailable, `"AC1: require 0 ≤ start < end ≤ 1440. Received start=−10, end=50."` |
| `05_i4_before_message_names_AC2.png` | Issue I4, before. `blocked = true`, request `720 / 841`, which violates AC2 and AC3 at once. The message blames AC2 although the room being blocked is the real reason. |
| `06_i4_after_message_names_AC3.png` | Issue I4, after. Same data, same input. The AC3 guard was moved ahead of the AC1 checks, and the message now names AC3. |
| `07_project_file_tree.png` | The generated project structure, as inspected in section 3.3 of the report. |

The verdict in 05 and 06 is `Unavailable` either way, so no automated test could detect the difference between them — only the message changes. That is why the repair is recorded as preventive cleanup rather than as a functional defect.
